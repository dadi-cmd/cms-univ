<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Etudiants::etudiants');

// $routes->get('/examen', 'ExamenMedical::examen');

$routes->get('/examen/(:any)', 'ExamenMedical::examen/$1');

$routes->get('/ExamenMedical/soumettre_examen', "ExamenMedical::soumettre_examen");

$routes->post('/soumission_examen', 'ExamenMedical::soumettre_examen');
// $routes->get('/soumission_examen', 'ExamenMedical::pdf_fiche');
// $routes->get('/pdf', 'PdfController::index');
$routes->get('/pdf', 'ExamenMedical::pdf_examen');

$routes->get('/fiche_medical/(:any)', 'ExamenMedical::fiche_examen_medical/$1');

$routes->get('/enrollement', 'Etudiants::enrollement');
$routes->post('/enroller', 'Etudiants::enroller');
$routes->get('/fiche_medical_pdf/(:any)/(:any)', 'ExamenMedical::pdf_fiche/$1/$2');