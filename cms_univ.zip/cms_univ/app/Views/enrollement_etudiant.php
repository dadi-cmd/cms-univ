<div class="container">
    <div class="row m-3 d-flex flex-row justify-content-center">
        <div class="col-6 m-4">
            <?= session()->getFlashdata('error') ?>
            <form class="form" action="<?= base_url('/enroller') ?>" method="post">
                <h4 class="text text-muted mb-4">Enrollement Etudiant</h4>
                <div class="mb-3">
                    <label for="matricule">Matricule</label>
                    <input type="text" name="matricule" id="matricule" class="form form-control">
                </div>
                <div class="mb-3">
                    <label for="nom">Nom</label>
                    <input type="text" name="nom" id="nom" class="form form-control">
                </div>
                <div class="mb-3">
                    <label for="prenom">Prenom</label>
                    <input type="text" name="prenom" id="prenom" class="form form-control">
                </div>
                <div class="mb-3">
                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" class="form form-control" placeholder="johndoe@email.com">
                </div>
                <div class="mb-3">
                    <input type="submit" name="enrollement" id="enrollement" value="Enrollement" class="form form-control btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</div>