<?php

namespace App\Controllers;

use App\Models\EtudiantsModel;

class Etudiants extends BaseController
{
    public function etudiants()
    {
        $model = model(EtudiantsModel::class);

        $data_etudiants =  [
            'liste_etudiants' => $model->getEtudiants()
        ];

        return view('templates/header')
            .view('etudiants', $data_etudiants);
    }

    public function enrollement(): string
    {
        return view('templates/header')
            .view('enrollement_etudiant');
    }

    public function enroller()
    {
        helper('form');

        $data = $this->request->getPost(['matricule', 'nom', 'prenom', 'email']);
        
        // Checks whether the submitted data passed the validation rules.
        if (!$this->validateData($data, [
            'matricule' => 'required',
            'nom'  => 'required',
            'prenom'  => 'required',
            'email'  => 'required|valid_email'
        ])) {
        // The validation fails, so returns the form.
            return $this->enrollement();
        }

        // Gets the validated data.
        $post = $this->validator->getValidated();

        $model = model(EtudiantsModel::class);

        $model->save([
            'matricule' => $post['matricule'],
            'nom' => $post['nom'],
            'prenom' => $post['prenom'],
            'email' => $post['email']
        ]);

        $data_etudiants =
            [
                'liste_etudiants' => $model->getEtudiants()
            ];

        return view('templates/header')
            .view('etudiants', $data_etudiants);
    }

}
