<?php

namespace App\Controllers;

use App\Models\ExamensModel;

class PdfController extends BaseController
{
    public function index()
    {

        // Recuperer les donnees des examens medicaux
        helper('form');
        $id_etudiant = $this->request->getGet('matricule');
        $data = $this->request->getGet(['matricule', 'temperature', 'pression', 'observation']);

        // $data_examen_etudiant = model(ExamensModel::class)->find($id_etudiant);
        $data_examen_etudiant = model(ExamensModel::class)->where('etudiant_id', $id_etudiant)->first();

        $data_success = model(ExamensModel::class)->find($id_etudiant);

        // Charger Dompdf
        require_once APPPATH . 'ThirdParty/dompdf/autoload.inc.php';

        // Namespace
        $dompdf = new \Dompdf\Dompdf();

        // HTML
        $html = "
        <div class=\"container mt-3\">
            <h2>Fiche Medical Etudiant</h2>
            <p>Liste des examens medicaux.</p>
            <h4 class=\"text text-muted\">Matricule: esp40023e{$id_etudiant}</h4>
            <table class=\"table\">
                <thead>
                    <tr>
                        <th>Examens Medicaux</th>
                        <th>Valeur</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Temperature</td>
                        <td>37{$data['temperature']}</td>
                    </tr>
                    <tr>
                        <td>Pression</td>
                        <td>8{$data['pression']}</td>
                    </tr>
                    <tr>
                        <td>Observations</td>
                        <td>Bien portant!{$data['observation']}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        ";

        // Charger HTML
        $dompdf->loadHtml($html);

        // Format papier
        $dompdf->setPaper('A4', 'portrait');

        // Génération
        $dompdf->render();

        // Affichage navigateur
        $dompdf->stream("fiche_medical_{$id_etudiant}.pdf", ["Attachment" => false]);
    }
}
