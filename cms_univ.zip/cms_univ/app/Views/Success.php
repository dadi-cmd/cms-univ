<h1 class="text text-success">Examen soumis</h1>
<p class="text text-muted">Examen effectué.</p>
<p class="text text-muted">Examen enregistré</p>

<div class="view">
    <h4><?= esc($matricule) ?></h4>
    <h4><?= esc($temperature) ?></h4>
    <h4><?= esc($pression) ?></h4>
    <h4><?= esc($observation) ?></h4>
</div>

<div class="text">
    <a href="<?= base_url('/pdf') ?>" class="btn btn-primary">Production du profile de Santé (Pdf)</a>
</div>

<div class="m-5">
    <a href="<?= base_url('/examen') ?>" class="btn btn-link">Retour A la liste d'etudiants</a>
</div>