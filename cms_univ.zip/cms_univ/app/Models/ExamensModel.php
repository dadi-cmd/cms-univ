<?php

namespace App\Models;

use CodeIgniter\Model;

class ExamensModel extends Model
{
    protected $table = 'examens';

    protected $primaryKey = 'id';

    public function getExamens()
    {
        return $this->findAll();
    }

    public function selectExamen($id_examen)
    {
        return $this->find($id_examen);
    }

    protected $allowedFields = ['etudiant_id', 'temperature', 'pression', 'observation'];
}
