<div class="container mt-4">
    <div class="row d-flex flex-row justify-content-center m-2">
        <div class="col-3">
            <h2>Examen medical</h2>
            <div class="text m-4">
                <h4>Etudiant : <?= $etudiant['nom'] ?></h4>
                <h6>matricule : <?= $etudiant['matricule'] ?></h6>
            </div>  
        </div>
        <form action="<?= base_url('/soumission_examen') ?>" method="post" class="d-flex justify-content-center">
            <div class="container">
                <div class="row m-5 d-flex flex-row justify-content-center">
                    <div class="col-4 d-flex flex-column justify-content-center">
                        <!-- <div class="mb-3 d-flex flex-column">
                            <label for="" class="form-control">Nom complet de l'etudiant</label>
                            <input type="text" name="nom" class="form-control" id="nom">
        
                        </div> -->
                        <div class="mb-3">
                            <label for="" class="form-control">Matricule de l'etudiant</label>
                            <input type="text" value="<?= $etudiant['matricule'] ?>" name="matricule" class="form-control" id="matricule">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-control">Temperature</label>
                            <input type="number" name="temperature" class="form-control" id="temperature">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-control">Pression</label>
                            <input type="number" name="pression" class="form-control" id="pression">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-control">Observation</label>
                            <textarea type="text" name="observation" class="form-control" id="observation"></textarea>
                        </div>

                        <div class="mb-3">
                            <!-- <a href="" class="btn btn-primary">Soumettre</a> -->
                            <button type="submit" class="btn btn-primary">Soumettre</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>