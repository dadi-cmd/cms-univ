<?php

namespace App\Controllers;

use App\Models\ExamensModel;
use App\Models\EtudiantsModel;

class ExamenMedical extends BaseController
{
    public function examen($id_etudiant = null)
    {
        // if($id_etudiant == null)
        // {
        //     return view('templates/header')
        //         . view('etudiants')
        //         . view('templates/footer');
        // }
        
        $model = model(EtudiantsModel::class);
        
        // $data = [
        //     'etudiant' => $model->selectEtudiant($id_etudiant)
        // ];

        $etudiant = $model->where('matricule', $id_etudiant)->first();

        if (!$etudiant){
            return redirect()->back();
        }

        $data['etudiant'] = $etudiant;
        
        return view('templates/header')
            .view('examen_medical', $data)
            .view('templates/footer');

    }
    public function soumettre_examen()
    {
        helper('form');
        
        $data = $this->request->getPost(['matricule', 'temperature', 'pression', 'observation']);

        // Checks whether the submitted data passed the validation rules.
        if (! $this->validateData($data, [
            'matricule' => 'required',
            'temperature'  => 'required',
            'pression'  => 'required',
            'observation'  => 'required|max_length[5000]'
        ])) {
            // The validation fails, so returns the form.
            return $this->examen();
        }

        // Gets the validated data.
        $post = $this->validator->getValidated();

        $model = model(ExamensModel::class);

        $model->save([
            'etudiant_id' => $post['matricule'],
            'temperature' => $post['temperature'],
            'pression' => $post['pression'],
            'observation' => $post['observation']
        ]);

        // Examen effectue

        // Changement de statut medical

        $model_etudiant = model(EtudiantsModel::class);

        $etudiant = $model_etudiant->where('matricule', $post['matricule'])->first();

        $update = $model_etudiant->update(
            $etudiant['id_etudiant'], 
            ['statut_medical' => 'examine']
        );
        if (!$update){
            return redirect()->back();
        }
        // return $model_etudiant->where('matricule', $post['matricule'])->first();

        $data_etudiants =  [
            'liste_etudiants' => $model_etudiant->getEtudiants()
        ];

        return view('templates/header')
            . view('etudiants', $data_etudiants);
    }

    public function pdf_examen()
    {
        require_once APPPATH . 'ThirdParty/dompdf/autoload.inc.php';

        $dompdf = new \Dompdf\Dompdf();


        // recuperation des valeurs du formulaire
        // helper('form');

        // $data_form = $this->request->getGet(['matricule', 'temperature', 'pression', 'observation']);

        // $id_etudiant = $this->request->getGet('matricule');

        // recuperation du model ExamensModel
        $model_examen = model(ExamensModel::class);

        $data_examen = $model_examen->where('etudiant_id', 'es424e')->first();

        // return view('pdf', $data_examen);

        // domping pdf
        $html = view('pdf', $data_examen);

        $dompdf->loadHtml($html);

        $dompdf->setPaper('A4', 'portrait');

        $dompdf->render();

        $dompdf->stream("examen_medical.pdf", ["Attachment" => false]);

    }

    public function pdf_fiche($etudiant_id, $examen_etudiant_id)
    {
        require_once APPPATH . 'ThirdParty/dompdf/autoload.inc.php';

        $dompdf = new \Dompdf\Dompdf();

        // $data = [
        //     'nom' => 'Arsène',
        //     'note' => 18
        // ];

        helper('form');

        $id_etudiant = $this->request->getGet('matricule');

        $data = [
            'informations_etudiant' => model(EtudiantsModel::class)->where('matricule', $etudiant_id)->first(),
            'examen_medical_etudiant' => model(ExamensModel::class)->where('etudiant_id', $examen_etudiant_id)->first()
        ];

        // domping pdf
        $html = view('fiche_examen_medical', $data);

        $dompdf->loadHtml($html);

        $dompdf->setPaper('A4', 'portrait');

        $dompdf->render();

        $dompdf->stream("bulletin.pdf", ["Attachment" => false]);
    }

    public function fiche_examen_medical($matricule_etudiant)
    {
        $model = model(ExamensModel::class);
        $model_etudiant = model(EtudiantsModel::class);

        // examen medical de l'etudiant concerne
        $data_examen = [
            'examen_medical_etudiant' => $model->where('etudiant_id', $matricule_etudiant)->first(),
            'informations_etudiant' => $model_etudiant->where('matricule', $matricule_etudiant)->first()
            ];
        return view('templates/header')
            .view('fiche_examen_medical', $data_examen);
    }
}
