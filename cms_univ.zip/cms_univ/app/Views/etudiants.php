<div class="container mt-3">
    <h2>Etudiants liste</h2>
    <p class="text text-muted">Les etudiants deja enregistres sur la plateforme.</p>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Matricule</th>
                <th>Nom</th>
                <th>Prenom</th>
                <th>Email</th>
                <th>Statut medical</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($liste_etudiants !== []): ?>
                <?php foreach ($liste_etudiants as $etudiant): ?>
                    <tr>
                        <td class="text text-muted"><?= $etudiant['matricule'] ?></td>
                        <td><?= $etudiant['nom'] ?></td>
                        <td><?= $etudiant['prenom'] ?></td>
                        <td><?= $etudiant['email'] ?></td>
                        <td>
                            <!-- Non-examiné -->
                            <?php if ($etudiant['statut_medical'] == 'examine'): ?>
                                <a href="<?= base_url("/fiche_medical//".$etudiant['matricule']) ?>" class="btn btn-success border-2 p-2">
                                    <span class="text">Examiné</span>
                                </a>
                            <?php else: ?>
                                <a href="<?= base_url('/examen//'.$etudiant['matricule']) ?>" class="btn btn-muted border-2 p-2">
                                    <span class="text">Non examiné</span>
                                </a>
                            <?php endif ?>    
                        </td>
                    </tr>

                <?php endforeach ?>
            <?php else: ?>
                <div class="text text-info border-3 border-info p-4">
                    <p>
                        Aucun etudiant n'a ete enrolle.
                    </p>
                </div>
            <?php endif ?>
        </tbody>
    </table>
</div>