<?php

namespace App\Models;

use CodeIgniter\Model;

class EtudiantsModel extends Model
{
    protected $table = 'etudiants';

    protected $primaryKey = 'id_etudiant';

    public function getEtudiants()
    {
        return $this->findAll();
    }

    // public function statutMedicalEtudiant($id, $statut)
    // {
    //     $update = $this->update($id, ['statut_medical' => $statut]);
    //     return $update;
    // }

    protected $allowedFields = ['matricule', 'nom', 'prenom', 'email', 'statut_medical'];
}
