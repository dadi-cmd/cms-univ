<div class="container">
    <div class="row">
        <div class="col d-flex flex-row justify-content-around pt-4">
            <div class="container-fluid">
                <h1>Fiche Medical Etudiant</h1>
                <p>
                <h4>Nom complet : <?= $informations_etudiant['nom'].' '.$informations_etudiant['prenom'] ?></h4>
                <h4>Matricule: <?= $examen_medical_etudiant['etudiant_id'] ?></h4>

                <div class="text mt-2">
                    <div class="mb-2">
                        <p class="text-muted">Temperature corporel : </p>
                        <p>
                            <?= $examen_medical_etudiant['temperature'] ?>
                        </p>
                    </div>
                    <div class="mb-2">
                        <p class="text-muted">Pression arteriel : </p>
                        <p>
                            <?= $examen_medical_etudiant['pression'] ?>
                        </p>
                    </div>
                    <div class="mb-2">
                        <p class="text-muted">Observation : </p>
                        <p>
                            <?= $examen_medical_etudiant['observation'] ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="pdf">
                <a href="<?= base_url('/fiche_medical_pdf//'.$informations_etudiant['matricule'].'/'.$examen_medical_etudiant['etudiant_id']) ?>" class="btn btn-success">Telecharger</a>
            </div>
        </div>
    </div>
</div>